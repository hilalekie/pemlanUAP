package uap.interfaces;

public interface Printable {
    void printInfo();
}
    

