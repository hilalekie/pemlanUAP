package uap.interfaces;

public interface MassCalculable {
    double hitungVolume();
    double hitungLuasPermukaan();
    double hitungMassa();
}