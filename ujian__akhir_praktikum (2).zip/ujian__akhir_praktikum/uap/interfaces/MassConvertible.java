package uap.interfaces;

public interface MassConvertible {
    double konversiKeKg();
    String hitungBiayaKirim();
    
}
